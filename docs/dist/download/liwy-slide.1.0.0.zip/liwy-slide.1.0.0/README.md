# liwy-slide
* 相关技术: grunt, karma, jquery等
* 示例: [https://liwyspace.github.io/liwy-slide/](https://liwyspace.github.io/liwy-slide/)
* 作者: liwy

> 官网: [开源小屋 www.oscafe.net](http://www.oscafe.net)  
> 邮箱: oscafe_net@163.com  
> QQ: 332301842  
>  
> 扫描关注微信公众号：开源小屋  
> ![开源小屋www.oscafe.net 公众平台二维码](./oscafe_qrcode.jpg)  

# 示例
[https://liwyspace.github.io/liwy-slide/](https://liwyspace.github.io/liwy-slide/)
![liwy-slide Demo](./demo.png)

## 支持
![微信付款码](./weixin_fkcode.jpg)
![支付宝付款码](./zhifubao_fkcode.jpg)

# License
MIT