/*! liwy-slide - v1.0.0 - 2017-08-20
* https://github.com/liwyspace/liwy-slide#readme
* Copyright (c) 2017 liwy; Licensed MIT */
/**
 * liwy-slide
 * @version 1.0.0
 * @author liwy
 * @license THe MIT License (MIT)
 */
;(function($, window, document, undefined) {

	/**
	 * 定义插件对象
	 * @public
	 * @param {HTMLElement|jQuery} element
	 * @param (Object) options
	 */
	var LiwySlide = function(element, options) {
		this.element = element;
		this.options = $.extend({},LiwySlide.defaults,options)
	};
	LiwySlide.defaults = {
		'color': 'red',
		'fontSize': '12px'
	};
	LiwySlide.prototype.setStyle = function() {
		return this.element.css({
			'color': this.options.color,
			'fontSize': this.options.fontSize
		});
	};


	//为jquery添加我们的liwy-slide插件
	$.fn.liwySlide = function(options) {

		return this.each(function() {
			return new LiwySlide(this,options).setStyle();
		});
	};
})(window.jQuery, window, document);