/*! liwy-slide - v1.0.0 - 2017-08-19
* https://github.com/liwyspace/liwy-slide#readme
* Copyright (c) 2017 liwy; Licensed MIT */
'use strict';
function add(a, b) {
	return a+b;
}